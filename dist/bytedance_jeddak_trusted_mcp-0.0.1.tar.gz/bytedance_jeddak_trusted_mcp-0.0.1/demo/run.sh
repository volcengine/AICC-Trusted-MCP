mv completions.py /app/.venv/lib/python3.12/site-packages/volcenginesdkarkruntime/resources/chat/completions.py

python agent.py